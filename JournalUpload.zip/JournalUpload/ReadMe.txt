Prerequisites:

-Access to an OCI tenancy.

-Identity domain of type Oracle Apps Premium and an admin account on it.

-A PeopleSoft SSO enabled instance with a valid SSL Certificate.

-A user with SSO access to PeopleSoft and the required privileges to upload Journals.

-A copy of fully functional Journal Upload spreadsheet currently working with username and password to push data.

-Local copy of the dependent file JRNLMACRO.xla for proper functioning.

-Basic knowledge on the VB Macro coding.



High Level Steps to configure Journal Upload with Device Code Flow.

1. Download the zip file from the Tutorial and Unzip the content.
2. The Folder should have both Journal upload and the Macro File in it.
3. Start by Creating a Confidential application as guided in the tutorial.
4. As mentioned in the tutorial, update your OCI IAM details in the spreadsheet under the functions mentioned in the tutorial. (The Spreadsheet should have the necessary prompts to guide you)
5. Update Online Update Control Address by Clicking ctrl+Fn+PgUp twice an replace the current address with the new SSO enabled address. (You should have your PeopleSoft SSO enabled with OCI IAM with a valid SSL certificate).
6. The Sheet might show you prompts to put in User ID and Password while uploading the files after editing it, you can put some random text and click on OK. (This behaviour can be updated by modifying the VB macro file )
7. The Device Code flow will kick in and rest process is same as described in tutorial.



Note:

1. Proof of Concept: This sheet serves as a proof of concept demonstrating that Excel to CI can support Device Code Flow for submitting data to the PeopleSoft database.

2. Code Quality: Note that the code may not adhere to best practices in VB coding. We strongly recommend thorough testing on your end before deploying it to a Production environment.

3. New Journal Upload Testing: The spreadsheet has been tested for new Journal upload use case. If it defaults to username and password authentication for any another functionality, you can modify the VB module to incorporate the device code logic for improved functionality. 

4. Opportunities for Enhancement: This follows the same as what we have scoped for Excel To CI in the Tutorial.
